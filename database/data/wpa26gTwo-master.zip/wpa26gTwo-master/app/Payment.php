<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
// Author: Nwe Ni Ei Kyaw 
class Payment extends Model
{
    //

    protected $fillable = ['name'];
}
