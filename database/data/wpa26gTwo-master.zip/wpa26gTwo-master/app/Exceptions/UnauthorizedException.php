<?php

namespace App\Exceptions;
class UnauthorizedException extends \Exception
{

}